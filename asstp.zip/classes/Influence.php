<?php 
class Influence
{
	// подключение к базе данных и имя таблицы
    private $conn;
    private $table_name = "Influence";
	
	// атрибуты - поля 
    protected $id_influence;
    protected $name;    
	
	public function __construct($db)
    {
        $this->conn = $db;
    }
	// метод создания 
    function create()
    {
        // запрос
        $query = "INSERT INTO " . $this->table_name . "
          SET id_influence=:id_influence, name=:name";

        $stmt = $this->conn->prepare($query);

        // значения
        $this->id_influence = htmlspecialchars(strip_tags($this->id_influence));
        $this->name = htmlspecialchars(strip_tags($this->name));
        
        // привязываем значения
        $stmt->bindParam(":id_influence", $this->id_influence);
        $stmt->bindParam(":name", $this->name);
        		
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
	// метод для получения записей
    function readAll()
    {
    // запрос MySQL
    $query = "SELECT
                id_influence, name
            FROM
                " . $this->table_name;

    $stmt = $this->conn->prepare($query);
    $stmt->execute();

    return $stmt;
    }
	function update()
{
    // MySQL запрос для обновления записи 
    $query = "UPDATE
                " . $this->table_name . "
            SET
                name = :name
            WHERE
                id_influence = :id_influence";

    // подготовка запроса
    $stmt = $this->conn->prepare($query);

    // очистка
    $this->id_influence = htmlspecialchars(strip_tags($this->id_influence));
    $this->name = htmlspecialchars(strip_tags($this->name));
    
    // привязка значений
    $stmt->bindParam(":id_influence", $this->id_influence);
    $stmt->bindParam(":name", $this->name);
    
    // выполняем запрос
    if ($stmt->execute()) {
        return true;
    }

    return false;
}
// метод для удаления 
function delete()
{
    // запрос MySQL для удаления
    $query = "DELETE FROM " . $this->table_name . " WHERE id_influence = ?";

    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->id_influence);

    if ($result = $stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
}
?>