<?php 
class Organization
{
	// подключение к базе данных и имя таблицы
    private $conn;
    private $table_name = "Organization";
	
	// атрибуты - поля 
    protected $id_org;
    protected $name;
    protected $address;
    protected $phone;
    protected $email;
	
	public function __construct($db)
    {
        $this->conn = $db;
    }
	// метод создания 
    function create()
    {
        // запрос
        $query = "INSERT INTO " . $this->table_name . "
          SET id_org=:id_org, name=:name, address=:address,
          phone=:phone, email=:email";

        $stmt = $this->conn->prepare($query);

        // значения
        $this->id_org = htmlspecialchars(strip_tags($this->id_org));
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->address = htmlspecialchars(strip_tags($this->address));
        $this->phone = htmlspecialchars(strip_tags($this->phone));
        $this->email = htmlspecialchars(strip_tags($this->email));

        // привязываем значения		
		$stmt->bindParam(":id_org", $this->id_org));
        $stmt->bindParam(":name", $this->name));
        $stmt->bindParam(":address", $this->address));
        $stmt->bindParam(":phone", $this->phone));
        $stmt->bindParam(":email", $this->email));		
		
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
	// метод для получения записей
    function readAll()
    {
    // запрос MySQL
    $query = "SELECT
                id_org, name, address, phone, email
            FROM
                " . $this->table_name;

    $stmt = $this->conn->prepare($query);
    $stmt->execute();

    return $stmt;
    }
	function update()
{
    // MySQL запрос для обновления записи 
    $query = "UPDATE
                " . $this->table_name . "
            SET
			name=:name,
            address=:address,
            phone=:phone,
            email=:email
			WHERE
                id_org = :id_org";

    // подготовка запроса
    $stmt = $this->conn->prepare($query);

    // очистка
    $this->id_org = htmlspecialchars(strip_tags($this->id_org));
    $this->name = htmlspecialchars(strip_tags($this->name));
    $this->address = htmlspecialchars(strip_tags($this->address));
    $this->phone = htmlspecialchars(strip_tags($this->phone));
    $this->email = htmlspecialchars(strip_tags($this->email));

    // привязка значений
    $stmt->bindParam(":id_org", $this->id_org));
    $stmt->bindParam(":name", $this->name));
    $stmt->bindParam(":address", $this->address));
    $stmt->bindParam(":phone", $this->phone));
    $stmt->bindParam(":email", $this->email));	

    // выполняем запрос
    if ($stmt->execute()) {
        return true;
    }

    return false;
}
// метод для удаления 
function delete()
{
    // запрос MySQL для удаления
    $query = "DELETE FROM " . $this->table_name . " WHERE id_org = ?";

    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->id_org);

    if ($result = $stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
}
?>