<?php 
class SLA
{
	// подключение к базе данных и имя таблицы
    private $conn;
    private $table_name = "SLA";
	
	// атрибуты - поля 
    protected $id_sla;
    protected $name;
    protected $time_provision;
    protected $downtime;
    protected $time_elimination;	
	
	public function __construct($db)
    {
        $this->conn = $db;
    }
	// метод создания 
    function create()
    {
        // запрос
        $query = "INSERT INTO " . $this->table_name . "
          SET id_sla=:id_sla, name=:name, time_provision=:time_provision,
		  downtime=:downtime, time_elimination=:time_elimination";

        $stmt = $this->conn->prepare($query);

        // значения
        
		$this->id_sla = htmlspecialchars(strip_tags($this->id_sla));
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->time_provision = htmlspecialchars(strip_tags($this->time_provision));
        $this->downtime = htmlspecialchars(strip_tags($this->downtime));
        $this->time_elimination = htmlspecialchars(strip_tags($this->time_elimination));

        // привязываем значения
        
		$stmt->bindParam(":id_sla", $this->id_sla);
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":time_provision", $this->time_provision);
        $stmt->bindParam(":downtime", $this->downtime);
        $stmt->bindParam(":time_elimination", $this->time_elimination);
		
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
	// метод для получения записей
    function readAll()
    {
    // запрос MySQL
    $query = "SELECT
                id_sla, name, time_provision, downtime, time_elimination				
            FROM
                " . $this->table_name;

    $stmt = $this->conn->prepare($query);
    $stmt->execute();

    return $stmt;
    }
	function update()
{
    // MySQL запрос для обновления записи 
    $query = "UPDATE
                " . $this->table_name . "
            SET                
                name=:name,
                time_provision=:time_provision,
                downtime=:downtime,
                time_elimination=:time_elimination				
            WHERE
                id_sla = :id_sla";

    // подготовка запроса
    $stmt = $this->conn->prepare($query);

    // очистка
   
	$this->id_sla = htmlspecialchars(strip_tags($this->id_sla));
    $this->name = htmlspecialchars(strip_tags($this->name));
    $this->time_provision = htmlspecialchars(strip_tags($this->time_provision));
    $this->downtime = htmlspecialchars(strip_tags($this->downtime));
    $this->time_elimination = htmlspecialchars(strip_tags($this->time_elimination));


    // привязка значений
    $stmt->bindParam(":id_sla", $this->id_sla);
    $stmt->bindParam(":name", $this->name);
    $stmt->bindParam(":time_provision", $this->time_provision);
    $stmt->bindParam(":downtime", $this->downtime);
    $stmt->bindParam(":time_elimination", $this->time_elimination);

    // выполняем запрос
    if ($stmt->execute()) {
        return true;
    }

    return false;
}
// метод для удаления 
function delete()
{
    // запрос MySQL для удаления
    $query = "DELETE FROM " . $this->table_name . " WHERE id_sla = ?";

    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->id_sla);

    if ($result = $stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
}
?>