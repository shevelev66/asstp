<?php 
class Ihistory
{
	// подключение к базе данных и имя таблицы
    private $conn;
    private $table_name = "Ihistory";
	
	// атрибуты - поля 
    	
	protected $id_history; 
    protected $id_incident; 
    protected $id_employee; 
    protected $time_action; 
    protected $action;
	
	public function __construct($db)
    {
        $this->conn = $db;
    }
	// метод создания 
    function create()
    {
        // запрос
        $query = "INSERT INTO " . $this->table_name . "
          SET 
		  id_history=:id_history,  
          id_incident=:id_incident, 
          id_employee=:id_employee, 
          time_action=:time_action, 
          action=:action";

        $stmt = $this->conn->prepare($query);

        // значения
        		
		$this->id_history = htmlspecialchars(strip_tags($this->id_history));  
        $this->id_incident = htmlspecialchars(strip_tags($this->id_incident)); 
        $this->id_employee = htmlspecialchars(strip_tags($this->id_employee)); 
        $this->time_action = htmlspecialchars(strip_tags($this->time_action)); 
        $this->action = htmlspecialchars(strip_tags($this->action));

        // привязываем значения
        
		$stmt->bindParam(":id_history", $this->id_history);  
        $stmt->bindParam(":id_incident", $this->id_incident); 
        $stmt->bindParam(":id_employee", $this->id_employee); 
        $stmt->bindParam(":time_action", $this->time_action); 
        $stmt->bindParam(":action", $this->action);
		
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
	// метод для получения записей
    function readAll()
    {
    // запрос MySQL
    $query = "SELECT
                id_history, id_incident, id_employee,
				time_action, action 				
            FROM
                " . $this->table_name;

    $stmt = $this->conn->prepare($query);
    $stmt->execute();

    return $stmt;
    }
	function update()
{
    // MySQL запрос для обновления записи 
    $query = "UPDATE
                " . $this->table_name . "
            SET
                id_incident=:id_incident, 
                id_employee=:id_employee, 
                time_action=:time_action, 
                action=:action 				
            WHERE
                id_history=:id_history";

    // подготовка запроса
    $stmt = $this->conn->prepare($query);

    // очистка
    $this->id_history = htmlspecialchars(strip_tags($this->id_history));  
    $this->id_incident = htmlspecialchars(strip_tags($this->id_incident)); 
    $this->id_employee = htmlspecialchars(strip_tags($this->id_employee)); 
    $this->time_action = htmlspecialchars(strip_tags($this->time_action)); 
    $this->action = htmlspecialchars(strip_tags($this->action));


    // привязка значений
    $stmt->bindParam(":id_history", $this->id_history);  
    $stmt->bindParam(":id_incident", $this->id_incident); 
    $stmt->bindParam(":id_employee", $this->id_employee); 
    $stmt->bindParam(":time_action", $this->time_action); 
    $stmt->bindParam(":action", $this->action);
		

    // выполняем запрос
    if ($stmt->execute()) {
        return true;
    }

    return false;
}
// метод для удаления 
function delete()
{
    // запрос MySQL для удаления
    $query = "DELETE FROM " . $this->table_name . " WHERE id_history = ?";

    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->id_history);

    if ($result = $stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
}
?>