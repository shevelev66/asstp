<?php 
class Priority
{
	// подключение к базе данных и имя таблицы
    private $conn;
    private $table_name = "Priority";
	
	// атрибуты - поля 
    protected $id_priority;
    protected $name;
	
	public function __construct($db)
    {
        $this->conn = $db;
    }
	// метод создания 
    function create()
    {
        // запрос
        $query = "INSERT INTO " . $this->table_name . "
          SET id_priority=:id_priority, name=:name";

        $stmt = $this->conn->prepare($query);

        // значения
        
		$this->id_priority = htmlspecialchars(strip_tags($this->id_priority));
        $this->name = htmlspecialchars(strip_tags($this->name));

        // привязываем значения
        
		$stmt->bindParam(":id_priority", $this->id_priority);
        $stmt->bindParam(":name", $this->name);
		
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
	// метод для получения записей
    function readAll()
    {
    // запрос MySQL
    $query = "SELECT                
				id_priority, name
            FROM
                " . $this->table_name;

    $stmt = $this->conn->prepare($query);
    $stmt->execute();

    return $stmt;
    }
	function update()
{
    // MySQL запрос для обновления записи 
    $query = "UPDATE
                " . $this->table_name . "
            SET	
				name=:name
            WHERE
                id_priority=:id_priority";

    // подготовка запроса
    $stmt = $this->conn->prepare($query);

    // очистка
    
	$this->id_priority = htmlspecialchars(strip_tags($this->id_priority));
    $this->name = htmlspecialchars(strip_tags($this->name));

    // привязка значений
    
	$stmt->bindParam(":id_priority", $this->id_priority);
    $stmt->bindParam(":name", $this->name);

    // выполняем запрос
    if ($stmt->execute()) {
        return true;
    }

    return false;
}
// метод для удаления 
function delete()
{
    // запрос MySQL для удаления
    $query = "DELETE FROM " . $this->table_name . " WHERE id_priority = ?";

    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->id_priority);

    if ($result = $stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
}
?>