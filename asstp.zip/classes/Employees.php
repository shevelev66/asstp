<?php 
class Employees
{
	// подключение к базе данных и имя таблицы
    private $conn;
    private $table_name = "Employees";
	
	// атрибуты - поля 
    	
    protected $id_employee;
    protected $surname;
    protected $name;
    protected $patronymic;
    protected $login;
    protected $password;
    protected $email;
    protected $work_phone;
    protected $ext_phone;
    protected $mob_phone;
    protected $id_role;
    protected $id_org;
    protected $department;
    protected $office;
    protected $position;
    protected $created;
    protected $updated;
    protected $active; 
	
	public function __construct($db)
    {
        $this->conn = $db;
    }
	// метод создания 
    function create()
    {
        // запрос
        $query = "INSERT INTO " . $this->table_name . "
          SET id_employee=:id_employee, surname=:surname,
		  name=:name, patronymic=:patronymic, login=:login,
		  password=:password, email=:email, work_phone=:work_phone,
		  ext_phone=:ext_phone, mob_phone=:mob_phone, id_role=:id_role,
		  id_org=:id_org, department=:department, office=:office,
		  position=:position, created=:created, updated=:updated, active=:active";		  

        $stmt = $this->conn->prepare($query);

        // значения
		$this->id_employee = htmlspecialchars(strip_tags($this->id_employee));
        $this->surname = htmlspecialchars(strip_tags($this->surname));
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->patronymic = htmlspecialchars(strip_tags($this->patronymic));
        $this->login = htmlspecialchars(strip_tags($this->login));
        $this->password = htmlspecialchars(strip_tags($this->password));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->work_phone = htmlspecialchars(strip_tags($this->work_phone));
        $this->ext_phone = htmlspecialchars(strip_tags($this->ext_phone));
        $this->mob_phone = htmlspecialchars(strip_tags($this->mob_phone));
        $this->id_role = htmlspecialchars(strip_tags($this->id_role));
        $this->id_org = htmlspecialchars(strip_tags($this->id_org));
        $this->department = htmlspecialchars(strip_tags($this->department));
        $this->office = htmlspecialchars(strip_tags($this->office));
        $this->position = htmlspecialchars(strip_tags($this->position));
        $this->created = htmlspecialchars(strip_tags($this->created));
        $this->updated = htmlspecialchars(strip_tags($this->updated));
        $this->active = htmlspecialchars(strip_tags($this->active));
	        
        // привязываем значения
		$stmt->bindParam(":id_employee", $this->id_employee);
        $stmt->bindParam(":surname", $this->surname);
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":patronymic", $this->patronymic);
        $stmt->bindParam(":login", $this->login);
        $stmt->bindParam(":password", $this->password);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":work_phone", $this->work_phone);
        $stmt->bindParam(":ext_phone", $this->ext_phone);
        $stmt->bindParam(":mob_phone", $this->mob_phone);
        $stmt->bindParam(":id_role", $this->id_role);
        $stmt->bindParam(":id_org", $this->id_org);
        $stmt->bindParam(":department", $this->department);
        $stmt->bindParam(":office", $this->office);
        $stmt->bindParam(":position", $this->position);
        $stmt->bindParam(":created", $this->created);
        $stmt->bindParam(":updated", $this->updated);
        $stmt->bindParam(":active", $this->active);
				
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
	// метод для получения записей
    function readAll()
    {
    // запрос MySQL
    $query = "SELECT
                id_employee, surname, name,
				patronymic, login, password,
				email, work_phone, ext_phone,
				mob_phone, id_role, id_org,
				department, office, position,
				created, updated, active 
            FROM
                " . $this->table_name;

    $stmt = $this->conn->prepare($query);
    $stmt->execute();

    return $stmt;
    }
	function update()
{
    // MySQL запрос для обновления записи 
    $query = "UPDATE
                " . $this->table_name . "
            SET			
			surname=:surname,			
		    name=:name,
			patronymic=:patronymic,
			login=:login,
			password=:password,
			email=:email,
			work_phone=:work_phone,
		    ext_phone=:ext_phone,
			mob_phone=:mob_phone,
			id_role=:id_role,
		    id_org=:id_org,
			department=:department,
			office=:office,
		    position=:position,
			created=:created,
			updated=:updated,
			active=:active                
            WHERE
                id_employee = :id_employee";

    // подготовка запроса
    $stmt = $this->conn->prepare($query);

    // очистка	
	$this->id_employee = htmlspecialchars(strip_tags($this->id_employee));
    $this->surname = htmlspecialchars(strip_tags($this->surname));
    $this->name = htmlspecialchars(strip_tags($this->name));
    $this->patronymic = htmlspecialchars(strip_tags($this->patronymic));
    $this->login = htmlspecialchars(strip_tags($this->login));
    $this->password = htmlspecialchars(strip_tags($this->password));
    $this->email = htmlspecialchars(strip_tags($this->email));
    $this->work_phone = htmlspecialchars(strip_tags($this->work_phone));
    $this->ext_phone = htmlspecialchars(strip_tags($this->ext_phone));
    $this->mob_phone = htmlspecialchars(strip_tags($this->mob_phone));
    $this->id_role = htmlspecialchars(strip_tags($this->id_role));
    $this->id_org = htmlspecialchars(strip_tags($this->id_org));
    $this->department = htmlspecialchars(strip_tags($this->department));
    $this->office = htmlspecialchars(strip_tags($this->office));
    $this->position = htmlspecialchars(strip_tags($this->position));
    $this->created = htmlspecialchars(strip_tags($this->created));
    $this->updated = htmlspecialchars(strip_tags($this->updated));
    $this->active = htmlspecialchars(strip_tags($this->active));

    // привязка значений    
	$stmt->bindParam(":id_employee", $this->id_employee);
    $stmt->bindParam(":surname", $this->surname);
    $stmt->bindParam(":name", $this->name);
    $stmt->bindParam(":patronymic", $this->patronymic);
    $stmt->bindParam(":login", $this->login);
    $stmt->bindParam(":password", $this->password);
    $stmt->bindParam(":email", $this->email);
    $stmt->bindParam(":work_phone", $this->work_phone);
    $stmt->bindParam(":ext_phone", $this->ext_phone);
    $stmt->bindParam(":mob_phone", $this->mob_phone);
    $stmt->bindParam(":id_role", $this->id_role);
    $stmt->bindParam(":id_org", $this->id_org);
    $stmt->bindParam(":department", $this->department);
    $stmt->bindParam(":office", $this->office);
    $stmt->bindParam(":position", $this->position);
    $stmt->bindParam(":created", $this->created);
    $stmt->bindParam(":updated", $this->updated);
    $stmt->bindParam(":active", $this->active);

    // выполняем запрос
    if ($stmt->execute()) {
        return true;
    }

    return false;
}
// метод для удаления 
function delete()
{
    // запрос MySQL для удаления
    $query = "DELETE FROM " . $this->table_name . " WHERE id_employee = ?";

    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->id_employee);

    if ($result = $stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
}
?>