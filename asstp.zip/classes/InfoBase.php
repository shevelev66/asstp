<?php 
class InfoBase
{
	// подключение к базе данных и имя таблицы
    private $conn;
    private $table_name = "InfoBase";
	
	// атрибуты - поля 
    protected $id_infobase;
    protected $id_employee;
    protected $name;
    protected $description;
    protected $created;
    protected $updated;
	
	public function __construct($db)
    {
        $this->conn = $db;
    }
	// метод создания 
    function create()
    {
        // запрос
        $query = "INSERT INTO " . $this->table_name . "
          SET id_infobase=:id_infobase, id_employee=:id_employee, name=:name,
		  description=:description, created=:created, updated=:updated";

        $stmt = $this->conn->prepare($query);

        // значения
        
		$this->id_infobase = htmlspecialchars(strip_tags($this->id_infobase));
        $this->id_employee = htmlspecialchars(strip_tags($this->id_employee));
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->description = htmlspecialchars(strip_tags($this->description));
        $this->created = htmlspecialchars(strip_tags($this->created));
        $this->updated = htmlspecialchars(strip_tags($this->updated));

        // привязываем значения
        
		$stmt->bindParam(":id_infobase", $this->id_infobase);
        $stmt->bindParam(":id_employee", $this->id_employee);
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":created", $this->created);
        $stmt->bindParam(":updated", $this->updated);
		
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
	// метод для получения записей
    function readAll()
    {
    // запрос MySQL
    $query = "SELECT
                id_infobase, id_employee, name=:name, description=:description,
				created=:created, updated=:updated
            FROM
                " . $this->table_name;

    $stmt = $this->conn->prepare($query);
    $stmt->execute();

    return $stmt;
    }
	function update()
{
    // MySQL запрос для обновления записи 
    $query = "UPDATE
                " . $this->table_name . "
            SET                
				id_employee=:id_employee,
				name=:name,
				description=:description,
				created=:created,
				updated=:updated				
            WHERE
                id_infobase = :id_infobase";

    // подготовка запроса
    $stmt = $this->conn->prepare($query);

    // очистка
    
	$this->id_infobase = htmlspecialchars(strip_tags($this->id_infobase));
    $this->id_employee = htmlspecialchars(strip_tags($this->id_employee));
    $this->name = htmlspecialchars(strip_tags($this->name));
    $this->description = htmlspecialchars(strip_tags($this->description));
    $this->created = htmlspecialchars(strip_tags($this->created));
    $this->updated = htmlspecialchars(strip_tags($this->updated));

    // привязка значений
    $stmt->bindParam(":id_infobase", $this->id_infobase);
    $stmt->bindParam(":id_employee", $this->id_employee);
    $stmt->bindParam(":name", $this->name);
    $stmt->bindParam(":description", $this->description);
    $stmt->bindParam(":created", $this->created);
    $stmt->bindParam(":updated", $this->updated);

    // выполняем запрос
    if ($stmt->execute()) {
        return true;
    }

    return false;
}
// метод для удаления 
function delete()
{
    // запрос MySQL для удаления
    $query = "DELETE FROM " . $this->table_name . " WHERE id_infobase = ?";

    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->id_infobase);

    if ($result = $stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
}
?>