<?php 
class Permits
{
	// подключение к базе данных и имя таблицы
    private $conn;
    private $table_name = "Permits";
	
	// атрибуты - поля 
    
	protected $id_permit;
    protected $id_role;
    protected $name;
    protected $description;
    protected $value;
	
	public function __construct($db)
    {
        $this->conn = $db;
    }
	// метод создания 
    function create()
    {
        // запрос
        $query = "INSERT INTO " . $this->table_name . "
          SET 
		  id_permit=:id_permit, id_role=:id_role, name=:name,
		  description=:description, value=:value";

        $stmt = $this->conn->prepare($query);

        // значения
        
		$this->id_permit = htmlspecialchars(strip_tags($this->id_permit));
        $this->id_role = htmlspecialchars(strip_tags($this->id_role));
        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->description = htmlspecialchars(strip_tags($this->description));
        $this->value = htmlspecialchars(strip_tags($this->value));

        // привязываем значения
        
		$stmt->bindParam(":id_permit", $this->id_permit);
        $stmt->bindParam(":id_role", $this->id_role);
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":value", $this->value);
		
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
	// метод для получения записей
    function readAll()
    {
    // запрос MySQL
    $query = "SELECT
                id_permit, id_role, name,
				description, value
            FROM
                " . $this->table_name;

    $stmt = $this->conn->prepare($query);
    $stmt->execute();

    return $stmt;
    }
	function update()
{
    // MySQL запрос для обновления записи 
    $query = "UPDATE
                " . $this->table_name . "
            SET
                id_role=:id_role,
                name=:name,
                description=:description,
                value=:value				
            WHERE
                id_permit=:id_permit";

    // подготовка запроса
    $stmt = $this->conn->prepare($query);

    // очистка
    
	$this->id_permit = htmlspecialchars(strip_tags($this->id_permit));
    $this->id_role = htmlspecialchars(strip_tags($this->id_role));
    $this->name = htmlspecialchars(strip_tags($this->name));
    $this->description = htmlspecialchars(strip_tags($this->description));
    $this->value = htmlspecialchars(strip_tags($this->value));

    // привязка значений
    
	$stmt->bindParam(":id_permit", $this->id_permit);
    $stmt->bindParam(":id_role", $this->id_role);
    $stmt->bindParam(":name", $this->name);
    $stmt->bindParam(":description", $this->description);
    $stmt->bindParam(":value", $this->value);
		

    // выполняем запрос
    if ($stmt->execute()) {
        return true;
    }

    return false;
}
// метод для удаления 
function delete()
{
    // запрос MySQL для удаления
    $query = "DELETE FROM " . $this->table_name . " WHERE id_permit = ?";

    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->id_permit);

    if ($result = $stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
}
?>