<?php 
class Incident
{
	// подключение к базе данных и имя таблицы
    private $conn;
    private $table_name = "Incident";
	
	// атрибуты - поля 
    	
	protected $id_incident;
    protected $id_employee;
    protected $id_priority;
    protected $id_status; 
    protected $id_service;
    protected $id_specialist; 
    protected $id_urgency;
    protected $id_influence;
    protected $id_sourse; 
    protected $name; 
    protected $description; 
    protected $created; 
    protected $updated; 
	
	public function __construct($db)
    {
        $this->conn = $db;
    }
	// метод создания 
    function create()
    {
        // запрос
        $query = "INSERT INTO " . $this->table_name . "
          SET 
		  id_incident=:id_incident, id_employee=:id_employee, id_priority=:id_priority,
		  id_status=:id_status, id_service=:id_service, id_specialist=:id_specialist, 
		  id_urgency=:id_urgency, id_influence=:id_influence, id_sourse=:id_sourse, 
		  name=:name, description=:description, created=:created, updated=:updated";

        $stmt = $this->conn->prepare($query);

        // значения        		
		$this->id_incident = htmlspecialchars(strip_tags($this->id_incident));
        $this->id_employee = htmlspecialchars(strip_tags($this->id_employee));
        $this->id_priority = htmlspecialchars(strip_tags($this->id_priority));
        $this->id_status = htmlspecialchars(strip_tags($this->id_status)); 
        $this->id_service = htmlspecialchars(strip_tags($this->id_service));
        $this->id_specialist = htmlspecialchars(strip_tags($this->id_specialist)); 
        $this->id_urgency = htmlspecialchars(strip_tags($this->id_urgency));
        $this->id_influence = htmlspecialchars(strip_tags($this->id_influence));
        $this->id_sourse = htmlspecialchars(strip_tags($this->id_sourse)); 
        $this->name = htmlspecialchars(strip_tags($this->name)); 
        $this->description = htmlspecialchars(strip_tags($this->description)); 
        $this->created = htmlspecialchars(strip_tags($this->created)); 
        $this->updated = htmlspecialchars(strip_tags($this->updated)); 

        // привязываем значения
        	
		$stmt->bindParam(":id_incident", $this->id_incident);
        $stmt->bindParam(":id_employee", $this->id_employee);
        $stmt->bindParam(":id_priority", $this->id_priority);
        $stmt->bindParam(":id_status", $this->id_status); 
        $stmt->bindParam(":id_service", $this->id_service);
        $stmt->bindParam(":id_specialist", $this->id_specialist); 
        $stmt->bindParam(":id_urgency", $this->id_urgency);
        $stmt->bindParam(":id_influence", $this->id_influence);
        $stmt->bindParam(":id_sourse", $this->id_sourse); 
        $stmt->bindParam(":name", $this->name); 
        $stmt->bindParam(":description", $this->description); 
        $stmt->bindParam(":created", $this->created); 
        $stmt->bindParam(":updated", $this->updated); 
		
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
	// метод для получения записей
    function readAll()
    {
    // запрос MySQL
    $query = "SELECT                
				id_incident, id_employee, id_priority, id_status, 
				id_service, id_specialist, id_urgency,
				id_influence, id_sourse, name, description,
				created, updated 
            FROM
                " . $this->table_name;

    $stmt = $this->conn->prepare($query);
    $stmt->execute();

    return $stmt;
    }
	function update()
{
    // MySQL запрос для обновления записи 
    $query = "UPDATE
                " . $this->table_name . "
            SET                
                id_employee=:id_employee,
                id_priority=:id_priority,
                id_status=:id_status, 
                id_service=:id_service,
                id_specialist=:id_specialist, 
                id_urgency=:id_urgency,
                id_influence=:id_influence,
                id_sourse=:id_sourse, 
                name=:name, 
                description=:description, 
                created=:created, 
                updated=:updated 
            WHERE
                id_incident = :id_incident";

    // подготовка запроса
    $stmt = $this->conn->prepare($query);

    // очистка
    $this->id_incident = htmlspecialchars(strip_tags($this->id_incident));
    $this->id_employee = htmlspecialchars(strip_tags($this->id_employee));
    $this->id_priority = htmlspecialchars(strip_tags($this->id_priority));
    $this->id_status = htmlspecialchars(strip_tags($this->id_status)); 
    $this->id_service = htmlspecialchars(strip_tags($this->id_service));
    $this->id_specialist = htmlspecialchars(strip_tags($this->id_specialist)); 
    $this->id_urgency = htmlspecialchars(strip_tags($this->id_urgency));
    $this->id_influence = htmlspecialchars(strip_tags($this->id_influence));
    $this->id_sourse = htmlspecialchars(strip_tags($this->id_sourse)); 
    $this->name = htmlspecialchars(strip_tags($this->name)); 
    $this->description = htmlspecialchars(strip_tags($this->description)); 
    $this->created = htmlspecialchars(strip_tags($this->created)); 
    $this->updated = htmlspecialchars(strip_tags($this->updated)); 

    // привязка значений
    $stmt->bindParam(":id_incident", $this->id_incident);
    $stmt->bindParam(":id_employee", $this->id_employee);
    $stmt->bindParam(":id_priority", $this->id_priority);
    $stmt->bindParam(":id_status", $this->id_status); 
    $stmt->bindParam(":id_service", $this->id_service);
    $stmt->bindParam(":id_specialist", $this->id_specialist); 
    $stmt->bindParam(":id_urgency", $this->id_urgency);
    $stmt->bindParam(":id_influence", $this->id_influence);
    $stmt->bindParam(":id_sourse", $this->id_sourse); 
    $stmt->bindParam(":name", $this->name); 
    $stmt->bindParam(":description", $this->description); 
    $stmt->bindParam(":created", $this->created); 
    $stmt->bindParam(":updated", $this->updated);

    // выполняем запрос
    if ($stmt->execute()) {
        return true;
    }

    return false;
}
// метод для удаления 
function delete()
{
    // запрос MySQL для удаления
    $query = "DELETE FROM " . $this->table_name . " WHERE id_incident = ?";

    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->id_incident);

    if ($result = $stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
}
?>