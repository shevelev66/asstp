<?php 
class Sourse
{
	// подключение к базе данных и имя таблицы
    private $conn;
    private $table_name = "Sourse";
	
	// атрибуты - поля 
    protected $id_sourse;
    protected $name;    
	
	public function __construct($db)
    {
        $this->conn = $db;
    }
	// метод создания 
    function create()
    {
        // запрос
        $query = "INSERT INTO " . $this->table_name . "
          SET id_sourse=:id_sourse, name=:name";

        $stmt = $this->conn->prepare($query);

        // значения
        $this->id_sourse = htmlspecialchars(strip_tags($this->id_sourse));
        $this->name = htmlspecialchars(strip_tags($this->name));
        
        // привязываем значения
        $stmt->bindParam(":id_sourse", $this->id_sourse);
        $stmt->bindParam(":name", $this->name);        
		
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
	// метод для получения записей
    function readAll()
    {
    // запрос MySQL
    $query = "SELECT
                id_sourse, name
            FROM
                " . $this->table_name;

    $stmt = $this->conn->prepare($query);
    $stmt->execute();

    return $stmt;
    }
	function update()
{
    // MySQL запрос для обновления записи 
    $query = "UPDATE
                " . $this->table_name . "
            SET
                name = :name                
            WHERE
                id_sourse = :id_sourse";

    // подготовка запроса
    $stmt = $this->conn->prepare($query);

    // очистка
    $this->id_sourse = htmlspecialchars(strip_tags($this->id_sourse));
    $this->name = htmlspecialchars(strip_tags($this->name));
    
    // привязка значений
    $stmt->bindParam(":id_sourse", $this->id_sourse);
    $stmt->bindParam(":name", $this->name);    

    // выполняем запрос
    if ($stmt->execute()) {
        return true;
    }

    return false;
}
// метод для удаления 
function delete()
{
    // запрос MySQL для удаления
    $query = "DELETE FROM " . $this->table_name . " WHERE id_sourse = ?";

    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->id_sourse);

    if ($result = $stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
}
?>