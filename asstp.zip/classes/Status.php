<?php 
class Status
{
	// подключение к базе данных и имя таблицы
    private $conn;
    private $table_name = "Status";
	
	// атрибуты - поля 
    protected $id_status;
    protected $name;
	
	public function __construct($db)
    {
        $this->conn = $db;
    }
	// метод создания 
    function create()
    {
        // запрос
        $query = "INSERT INTO " . $this->table_name . "
          SET id_status=:id_status, name=:name";

        $stmt = $this->conn->prepare($query);

        // значения
        
		$this->id_status = htmlspecialchars(strip_tags($this->id_status));
        $this->name = htmlspecialchars(strip_tags($this->name));

        // привязываем значения
        
		$stmt->bindParam(":id_status", $this->id_status);
        $stmt->bindParam(":name", $this->name);
		
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
	// метод для получения записей
    function readAll()
    {
    // запрос MySQL
    $query = "SELECT                
				id_status, name
            FROM
                " . $this->table_name;

    $stmt = $this->conn->prepare($query);
    $stmt->execute();

    return $stmt;
    }
	function update()
{
    // MySQL запрос для обновления записи 
    $query = "UPDATE
                " . $this->table_name . "
            SET                
				name=:name
            WHERE
                id_status=:id_status";

    // подготовка запроса
    $stmt = $this->conn->prepare($query);

    // очистка
    $this->id_status = htmlspecialchars(strip_tags($this->id_status));
    $this->name = htmlspecialchars(strip_tags($this->name));

    // привязка значений
    $stmt->bindParam(":id_status", $this->id_status);
    $stmt->bindParam(":name", $this->name);

    // выполняем запрос
    if ($stmt->execute()) {
        return true;
    }

    return false;
}
// метод для удаления 
function delete()
{
    // запрос MySQL для удаления
    $query = "DELETE FROM " . $this->table_name . " WHERE id_status = ?";

    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->id_status);

    if ($result = $stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
}
?>