<?php 
class Service
{
	// подключение к базе данных и имя таблицы
    private $conn;
    private $table_name = "Service";
	
	// атрибуты - поля 
    protected $id_service; 
    protected $id_catalog; 
    protected $id_sla; 
    protected $name; 
    protected $description;
	
	public function __construct($db)
    {
        $this->conn = $db;
    }
	// метод создания 
    function create()
    {
        // запрос
        $query = "INSERT INTO " . $this->table_name . "
          SET 
		  id_service=:id_service,  
          id_catalog=:id_catalog, 
          id_sla=:id_sla,
          name=:name,  
          description=:description";

        $stmt = $this->conn->prepare($query);

        // значения
        		
		$this->id_service = htmlspecialchars(strip_tags($this->id_service));  
        $this->id_catalog = htmlspecialchars(strip_tags($this->id_catalog)); 
        $this->id_sla = htmlspecialchars(strip_tags($this->id_sla));
        $this->name = htmlspecialchars(strip_tags($this->name));  
        $this->description = htmlspecialchars(strip_tags($this->description));

        // привязываем значения
        
		$stmt->bindParam(":id_service", $this->id_service);  
        $stmt->bindParam(":id_catalog", $this->id_catalog); 
        $stmt->bindParam(":id_sla", $this->id_sla);
        $stmt->bindParam(":name", $this->name);  
        $stmt->bindParam(":description", $this->description);
		
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
	// метод для получения записей
    function readAll()
    {
    // запрос MySQL
    $query = "SELECT                
				id_service, id_catalog, id_sla,
				name, description
            FROM
                " . $this->table_name;

    $stmt = $this->conn->prepare($query);
    $stmt->execute();

    return $stmt;
    }
	function update()
{
    // MySQL запрос для обновления записи 
    $query = "UPDATE
                " . $this->table_name . "
            SET
                id_catalog=:id_catalog, 
                id_sla=:id_sla,
                name=:name,  
                description=:description
				
            WHERE
                id_service=:id_service";

    // подготовка запроса
    $stmt = $this->conn->prepare($query);

    // очистка
   $this->id_service = htmlspecialchars(strip_tags($this->id_service));  
   $this->id_catalog = htmlspecialchars(strip_tags($this->id_catalog)); 
   $this->id_sla = htmlspecialchars(strip_tags($this->id_sla));
   $this->name = htmlspecialchars(strip_tags($this->name));  
   $this->description = htmlspecialchars(strip_tags($this->description));

    // привязка значений
    $stmt->bindParam(":id_service", $this->id_service);  
    $stmt->bindParam(":id_catalog", $this->id_catalog); 
    $stmt->bindParam(":id_sla", $this->id_sla);
    $stmt->bindParam(":name", $this->name);  
    $stmt->bindParam(":description", $this->description);

    // выполняем запрос
    if ($stmt->execute()) {
        return true;
    }

    return false;
}
// метод для удаления 
function delete()
{
    // запрос MySQL для удаления
    $query = "DELETE FROM " . $this->table_name . " WHERE id_service = ?";

    $stmt = $this->conn->prepare($query);
    $stmt->bindParam(1, $this->id_service);

    if ($result = $stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
}
?>