<?php
$dalTableInfoBase = array();
$dalTableInfoBase["id_infobase"] = array("type"=>3,"varname"=>"id_infobase", "name" => "id_infobase", "autoInc" => "1");
$dalTableInfoBase["id_employee"] = array("type"=>3,"varname"=>"id_employee", "name" => "id_employee", "autoInc" => "0");
$dalTableInfoBase["name"] = array("type"=>200,"varname"=>"name", "name" => "name", "autoInc" => "0");
$dalTableInfoBase["description"] = array("type"=>201,"varname"=>"description", "name" => "description", "autoInc" => "0");
$dalTableInfoBase["created"] = array("type"=>135,"varname"=>"created", "name" => "created", "autoInc" => "0");
$dalTableInfoBase["updated"] = array("type"=>135,"varname"=>"updated", "name" => "updated", "autoInc" => "0");
$dalTableInfoBase["id_infobase"]["key"]=true;

$dal_info["shadb3_at_localhost__InfoBase"] = &$dalTableInfoBase;
?>