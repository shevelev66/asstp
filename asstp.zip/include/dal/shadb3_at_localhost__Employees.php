<?php
$dalTableEmployees = array();
$dalTableEmployees["id_employee"] = array("type"=>3,"varname"=>"id_employee", "name" => "id_employee", "autoInc" => "1");
$dalTableEmployees["surname"] = array("type"=>200,"varname"=>"surname", "name" => "surname", "autoInc" => "0");
$dalTableEmployees["name"] = array("type"=>200,"varname"=>"name", "name" => "name", "autoInc" => "0");
$dalTableEmployees["patronymic"] = array("type"=>200,"varname"=>"patronymic", "name" => "patronymic", "autoInc" => "0");
$dalTableEmployees["login"] = array("type"=>200,"varname"=>"login", "name" => "login", "autoInc" => "0");
$dalTableEmployees["password"] = array("type"=>200,"varname"=>"password", "name" => "password", "autoInc" => "0");
$dalTableEmployees["email"] = array("type"=>200,"varname"=>"email", "name" => "email", "autoInc" => "0");
$dalTableEmployees["work_phone"] = array("type"=>200,"varname"=>"work_phone", "name" => "work_phone", "autoInc" => "0");
$dalTableEmployees["ext_phone"] = array("type"=>200,"varname"=>"ext_phone", "name" => "ext_phone", "autoInc" => "0");
$dalTableEmployees["mob_phone"] = array("type"=>200,"varname"=>"mob_phone", "name" => "mob_phone", "autoInc" => "0");
$dalTableEmployees["id_role"] = array("type"=>3,"varname"=>"id_role", "name" => "id_role", "autoInc" => "0");
$dalTableEmployees["id_org"] = array("type"=>3,"varname"=>"id_org", "name" => "id_org", "autoInc" => "0");
$dalTableEmployees["department"] = array("type"=>200,"varname"=>"department", "name" => "department", "autoInc" => "0");
$dalTableEmployees["office"] = array("type"=>200,"varname"=>"office", "name" => "office", "autoInc" => "0");
$dalTableEmployees["position"] = array("type"=>200,"varname"=>"position", "name" => "position", "autoInc" => "0");
$dalTableEmployees["created"] = array("type"=>135,"varname"=>"created", "name" => "created", "autoInc" => "0");
$dalTableEmployees["updated"] = array("type"=>135,"varname"=>"updated", "name" => "updated", "autoInc" => "0");
$dalTableEmployees["active"] = array("type"=>16,"varname"=>"active", "name" => "active", "autoInc" => "0");
$dalTableEmployees["id_employee"]["key"]=true;

$dal_info["shadb3_at_localhost__Employees"] = &$dalTableEmployees;
?>