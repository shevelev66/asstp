<?php
$dalTablePhistory = array();
$dalTablePhistory["id_history"] = array("type"=>3,"varname"=>"id_history", "name" => "id_history", "autoInc" => "1");
$dalTablePhistory["id_problem"] = array("type"=>3,"varname"=>"id_problem", "name" => "id_problem", "autoInc" => "0");
$dalTablePhistory["id_employee"] = array("type"=>3,"varname"=>"id_employee", "name" => "id_employee", "autoInc" => "0");
$dalTablePhistory["time_action"] = array("type"=>135,"varname"=>"time_action", "name" => "time_action", "autoInc" => "0");
$dalTablePhistory["action"] = array("type"=>201,"varname"=>"action", "name" => "action", "autoInc" => "0");
$dalTablePhistory["id_history"]["key"]=true;

$dal_info["shadb3_at_localhost__Phistory"] = &$dalTablePhistory;
?>