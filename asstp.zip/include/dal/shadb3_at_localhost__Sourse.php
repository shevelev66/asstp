<?php
$dalTableSourse = array();
$dalTableSourse["id_sourse"] = array("type"=>3,"varname"=>"id_sourse", "name" => "id_sourse", "autoInc" => "1");
$dalTableSourse["name"] = array("type"=>200,"varname"=>"name", "name" => "name", "autoInc" => "0");
$dalTableSourse["id_sourse"]["key"]=true;

$dal_info["shadb3_at_localhost__Sourse"] = &$dalTableSourse;
?>