<?php
$dalTableOrganization = array();
$dalTableOrganization["id_org"] = array("type"=>3,"varname"=>"id_org", "name" => "id_org", "autoInc" => "1");
$dalTableOrganization["name"] = array("type"=>200,"varname"=>"name", "name" => "name", "autoInc" => "0");
$dalTableOrganization["address"] = array("type"=>200,"varname"=>"address", "name" => "address", "autoInc" => "0");
$dalTableOrganization["phone"] = array("type"=>200,"varname"=>"phone", "name" => "phone", "autoInc" => "0");
$dalTableOrganization["email"] = array("type"=>200,"varname"=>"email", "name" => "email", "autoInc" => "0");
$dalTableOrganization["id_org"]["key"]=true;

$dal_info["shadb3_at_localhost__Organization"] = &$dalTableOrganization;
?>