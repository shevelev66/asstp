<?php
$dalTableService = array();
$dalTableService["id_service"] = array("type"=>3,"varname"=>"id_service", "name" => "id_service", "autoInc" => "1");
$dalTableService["id_catalog"] = array("type"=>3,"varname"=>"id_catalog", "name" => "id_catalog", "autoInc" => "0");
$dalTableService["id_sla"] = array("type"=>3,"varname"=>"id_sla", "name" => "id_sla", "autoInc" => "0");
$dalTableService["name"] = array("type"=>200,"varname"=>"name", "name" => "name", "autoInc" => "0");
$dalTableService["description"] = array("type"=>201,"varname"=>"description", "name" => "description", "autoInc" => "0");
$dalTableService["id_service"]["key"]=true;

$dal_info["shadb3_at_localhost__Service"] = &$dalTableService;
?>