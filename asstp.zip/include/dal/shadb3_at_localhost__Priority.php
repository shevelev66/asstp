<?php
$dalTablePriority = array();
$dalTablePriority["id_priority"] = array("type"=>3,"varname"=>"id_priority", "name" => "id_priority", "autoInc" => "1");
$dalTablePriority["name"] = array("type"=>200,"varname"=>"name", "name" => "name", "autoInc" => "0");
$dalTablePriority["id_priority"]["key"]=true;

$dal_info["shadb3_at_localhost__Priority"] = &$dalTablePriority;
?>