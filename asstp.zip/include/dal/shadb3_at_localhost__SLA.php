<?php
$dalTableSLA = array();
$dalTableSLA["id_sla"] = array("type"=>3,"varname"=>"id_sla", "name" => "id_sla", "autoInc" => "1");
$dalTableSLA["name"] = array("type"=>200,"varname"=>"name", "name" => "name", "autoInc" => "0");
$dalTableSLA["time_provision"] = array("type"=>200,"varname"=>"time_provision", "name" => "time_provision", "autoInc" => "0");
$dalTableSLA["downtime"] = array("type"=>200,"varname"=>"downtime", "name" => "downtime", "autoInc" => "0");
$dalTableSLA["time_elimination"] = array("type"=>200,"varname"=>"time_elimination", "name" => "time_elimination", "autoInc" => "0");
$dalTableSLA["id_sla"]["key"]=true;

$dal_info["shadb3_at_localhost__SLA"] = &$dalTableSLA;
?>