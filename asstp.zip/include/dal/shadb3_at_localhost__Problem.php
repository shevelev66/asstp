<?php
$dalTableProblem = array();
$dalTableProblem["id_problem"] = array("type"=>3,"varname"=>"id_problem", "name" => "id_problem", "autoInc" => "1");
$dalTableProblem["id_employee"] = array("type"=>3,"varname"=>"id_employee", "name" => "id_employee", "autoInc" => "0");
$dalTableProblem["id_priority"] = array("type"=>3,"varname"=>"id_priority", "name" => "id_priority", "autoInc" => "0");
$dalTableProblem["id_status"] = array("type"=>3,"varname"=>"id_status", "name" => "id_status", "autoInc" => "0");
$dalTableProblem["id_service"] = array("type"=>3,"varname"=>"id_service", "name" => "id_service", "autoInc" => "0");
$dalTableProblem["id_specialist"] = array("type"=>3,"varname"=>"id_specialist", "name" => "id_specialist", "autoInc" => "0");
$dalTableProblem["id_urgency"] = array("type"=>3,"varname"=>"id_urgency", "name" => "id_urgency", "autoInc" => "0");
$dalTableProblem["name"] = array("type"=>200,"varname"=>"name", "name" => "name", "autoInc" => "0");
$dalTableProblem["description"] = array("type"=>201,"varname"=>"description", "name" => "description", "autoInc" => "0");
$dalTableProblem["id_influence"] = array("type"=>3,"varname"=>"id_influence", "name" => "id_influence", "autoInc" => "0");
$dalTableProblem["created"] = array("type"=>135,"varname"=>"created", "name" => "created", "autoInc" => "0");
$dalTableProblem["updated"] = array("type"=>135,"varname"=>"updated", "name" => "updated", "autoInc" => "0");
$dalTableProblem["id_problem"]["key"]=true;

$dal_info["shadb3_at_localhost__Problem"] = &$dalTableProblem;
?>