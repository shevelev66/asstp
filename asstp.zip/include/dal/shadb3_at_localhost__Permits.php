<?php
$dalTablePermits = array();
$dalTablePermits["id_permit"] = array("type"=>3,"varname"=>"id_permit", "name" => "id_permit", "autoInc" => "1");
$dalTablePermits["id_role"] = array("type"=>3,"varname"=>"id_role", "name" => "id_role", "autoInc" => "0");
$dalTablePermits["name"] = array("type"=>200,"varname"=>"name", "name" => "name", "autoInc" => "0");
$dalTablePermits["description"] = array("type"=>200,"varname"=>"description", "name" => "description", "autoInc" => "0");
$dalTablePermits["value"] = array("type"=>3,"varname"=>"fldvalue", "name" => "value", "autoInc" => "0");
$dalTablePermits["id_permit"]["key"]=true;

$dal_info["shadb3_at_localhost__Permits"] = &$dalTablePermits;
?>