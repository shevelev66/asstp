<?php
$dalTableUrgency = array();
$dalTableUrgency["id_urgency"] = array("type"=>3,"varname"=>"id_urgency", "name" => "id_urgency", "autoInc" => "1");
$dalTableUrgency["name"] = array("type"=>200,"varname"=>"name", "name" => "name", "autoInc" => "0");
$dalTableUrgency["id_urgency"]["key"]=true;

$dal_info["shadb3_at_localhost__Urgency"] = &$dalTableUrgency;
?>