<?php
$dalTableCatalogService = array();
$dalTableCatalogService["id_catalog"] = array("type"=>3,"varname"=>"id_catalog", "name" => "id_catalog", "autoInc" => "1");
$dalTableCatalogService["name"] = array("type"=>200,"varname"=>"name", "name" => "name", "autoInc" => "0");
$dalTableCatalogService["description"] = array("type"=>201,"varname"=>"description", "name" => "description", "autoInc" => "0");
$dalTableCatalogService["id_catalog"]["key"]=true;

$dal_info["shadb3_at_localhost__CatalogService"] = &$dalTableCatalogService;
?>