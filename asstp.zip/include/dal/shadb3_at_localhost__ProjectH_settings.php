<?php
$dalTableProjectH_settings = array();
$dalTableProjectH_settings["ID"] = array("type"=>3,"varname"=>"ID", "name" => "ID", "autoInc" => "1");
$dalTableProjectH_settings["TYPE"] = array("type"=>3,"varname"=>"TYPE", "name" => "TYPE", "autoInc" => "0");
$dalTableProjectH_settings["NAME"] = array("type"=>201,"varname"=>"NAME", "name" => "NAME", "autoInc" => "0");
$dalTableProjectH_settings["USERNAME"] = array("type"=>201,"varname"=>"USERNAME", "name" => "USERNAME", "autoInc" => "0");
$dalTableProjectH_settings["COOKIE"] = array("type"=>200,"varname"=>"COOKIE", "name" => "COOKIE", "autoInc" => "0");
$dalTableProjectH_settings["SEARCH"] = array("type"=>201,"varname"=>"SEARCH", "name" => "SEARCH", "autoInc" => "0");
$dalTableProjectH_settings["TABLENAME"] = array("type"=>200,"varname"=>"TABLENAME", "name" => "TABLENAME", "autoInc" => "0");
$dalTableProjectH_settings["ID"]["key"]=true;

$dal_info["shadb3_at_localhost__ProjectH_settings"] = &$dalTableProjectH_settings;
?>