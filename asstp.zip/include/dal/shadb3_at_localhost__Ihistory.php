<?php
$dalTableIhistory = array();
$dalTableIhistory["id_history"] = array("type"=>3,"varname"=>"id_history", "name" => "id_history", "autoInc" => "1");
$dalTableIhistory["id_incident"] = array("type"=>3,"varname"=>"id_incident", "name" => "id_incident", "autoInc" => "0");
$dalTableIhistory["id_employee"] = array("type"=>3,"varname"=>"id_employee", "name" => "id_employee", "autoInc" => "0");
$dalTableIhistory["time_action"] = array("type"=>135,"varname"=>"time_action", "name" => "time_action", "autoInc" => "0");
$dalTableIhistory["action"] = array("type"=>201,"varname"=>"action", "name" => "action", "autoInc" => "0");
$dalTableIhistory["id_history"]["key"]=true;

$dal_info["shadb3_at_localhost__Ihistory"] = &$dalTableIhistory;
?>