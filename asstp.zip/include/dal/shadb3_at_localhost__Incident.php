<?php
$dalTableIncident = array();
$dalTableIncident["id_incident"] = array("type"=>3,"varname"=>"id_incident", "name" => "id_incident", "autoInc" => "1");
$dalTableIncident["id_employee"] = array("type"=>3,"varname"=>"id_employee", "name" => "id_employee", "autoInc" => "0");
$dalTableIncident["id_priority"] = array("type"=>3,"varname"=>"id_priority", "name" => "id_priority", "autoInc" => "0");
$dalTableIncident["id_status"] = array("type"=>3,"varname"=>"id_status", "name" => "id_status", "autoInc" => "0");
$dalTableIncident["id_service"] = array("type"=>3,"varname"=>"id_service", "name" => "id_service", "autoInc" => "0");
$dalTableIncident["id_specialist"] = array("type"=>3,"varname"=>"id_specialist", "name" => "id_specialist", "autoInc" => "0");
$dalTableIncident["id_urgency"] = array("type"=>3,"varname"=>"id_urgency", "name" => "id_urgency", "autoInc" => "0");
$dalTableIncident["id_influence"] = array("type"=>3,"varname"=>"id_influence", "name" => "id_influence", "autoInc" => "0");
$dalTableIncident["id_sourse"] = array("type"=>3,"varname"=>"id_sourse", "name" => "id_sourse", "autoInc" => "0");
$dalTableIncident["name"] = array("type"=>200,"varname"=>"name", "name" => "name", "autoInc" => "0");
$dalTableIncident["description"] = array("type"=>201,"varname"=>"description", "name" => "description", "autoInc" => "0");
$dalTableIncident["created"] = array("type"=>135,"varname"=>"created", "name" => "created", "autoInc" => "0");
$dalTableIncident["updated"] = array("type"=>135,"varname"=>"updated", "name" => "updated", "autoInc" => "0");
$dalTableIncident["id_incident"]["key"]=true;

$dal_info["shadb3_at_localhost__Incident"] = &$dalTableIncident;
?>