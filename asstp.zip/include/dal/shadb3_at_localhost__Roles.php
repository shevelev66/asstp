<?php
$dalTableRoles = array();
$dalTableRoles["id_role"] = array("type"=>3,"varname"=>"id_role", "name" => "id_role", "autoInc" => "1");
$dalTableRoles["name"] = array("type"=>200,"varname"=>"name", "name" => "name", "autoInc" => "0");
$dalTableRoles["value"] = array("type"=>200,"varname"=>"fldvalue", "name" => "value", "autoInc" => "0");
$dalTableRoles["id_role"]["key"]=true;

$dal_info["shadb3_at_localhost__Roles"] = &$dalTableRoles;
?>